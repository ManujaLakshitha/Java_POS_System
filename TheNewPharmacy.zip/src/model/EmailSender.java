/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.IOException;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

/**
 *
 * @author sande
 */
public class EmailSender {

    public static void setToAddress(String toAddress) {
        EmailSender.toAddress = toAddress;
    }

    public static void setSubject(String subject) {
        EmailSender.subject = subject;
    }

    public static void setMessage(String message) {
        EmailSender.message = message;
    }

    public static void setFilePath(String aFilePath) {
        filePath = aFilePath;
    }

    private static String subject;
    private static String toAddress;
    private static String message;
    private static String filePath = "";

    public static String send() throws IOException {
        String status = "";

        // SMTP server configuration
        String host = "smtp.gmail.com";
        String port = "587";
        final String username = "worasolutionslk@gmail.com";
        final String password = "xyyumlltikbluygx";

        // Set up properties object
        Properties props = new Properties();
        props.put("mail.smtp.host", host);
        props.put("mail.smtp.port", port);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        // Create a session with an authenticator
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            // Create a new email message
            Message msg = new MimeMessage(session);

            msg.setFrom(new InternetAddress(username));
            InternetAddress[] toAddresses = {new InternetAddress(toAddress)};
            msg.setRecipients(Message.RecipientType.TO, toAddresses);
            msg.setSubject(subject);
            msg.setSentDate(new java.util.Date());

            if (!filePath.equals("")) {
                MimeBodyPart textAttachment = new MimeBodyPart();
                MimeBodyPart pdfAttachment = new MimeBodyPart();
                MimeMultipart emailContent = new MimeMultipart();

                textAttachment.setText(message);
                pdfAttachment.attachFile(filePath);

                emailContent.addBodyPart(textAttachment);
                emailContent.addBodyPart(pdfAttachment);

                msg.setContent(emailContent);
            } else {
                msg.setText(message);
            }

            // Send the email
            Transport.send(msg);
            status = "Success";

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return status;
    }
}
