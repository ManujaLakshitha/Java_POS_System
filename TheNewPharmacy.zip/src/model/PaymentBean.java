package model;

public class PaymentBean {
    private String COLUMN_0;
    private String COLUMN_1;
    private String COLUMN_2;
    private String COLUMN_3;
    private String COLUMN_4;
    private String COLUMN_5;
    private String COLUMN_6;

    /**
     * @return the COLUMN_0
     */
    public String getCOLUMN_0() {
        return COLUMN_0;
    }

    /**
     * @param COLUMN_0 the COLUMN_0 to set
     */
    public void setCOLUMN_0(String COLUMN_0) {
        this.COLUMN_0 = COLUMN_0;
    }

    /**
     * @return the COLUMN_1
     */
    public String getCOLUMN_1() {
        return COLUMN_1;
    }

    /**
     * @param COLUMN_1 the COLUMN_1 to set
     */
    public void setCOLUMN_1(String COLUMN_1) {
        this.COLUMN_1 = COLUMN_1;
    }

    /**
     * @return the COLUMN_2
     */
    public String getCOLUMN_2() {
        return COLUMN_2;
    }

    /**
     * @param COLUMN_2 the COLUMN_2 to set
     */
    public void setCOLUMN_2(String COLUMN_2) {
        this.COLUMN_2 = COLUMN_2;
    }

    /**
     * @return the COLUMN_3
     */
    public String getCOLUMN_3() {
        return COLUMN_3;
    }

    /**
     * @param COLUMN_3 the COLUMN_3 to set
     */
    public void setCOLUMN_3(String COLUMN_3) {
        this.COLUMN_3 = COLUMN_3;
    }

    /**
     * @return the COLUMN_4
     */
    public String getCOLUMN_4() {
        return COLUMN_4;
    }

    /**
     * @param COLUMN_4 the COLUMN_4 to set
     */
    public void setCOLUMN_4(String COLUMN_4) {
        this.COLUMN_4 = COLUMN_4;
    }

    /**
     * @return the COLUMN_5
     */
    public String getCOLUMN_5() {
        return COLUMN_5;
    }

    /**
     * @param COLUMN_5 the COLUMN_5 to set
     */
    public void setCOLUMN_5(String COLUMN_5) {
        this.COLUMN_5 = COLUMN_5;
    }

    /**
     * @return the COLUMN_6
     */
    public String getCOLUMN_6() {
        return COLUMN_6;
    }

    /**
     * @param COLUMN_6 the COLUMN_6 to set
     */
    public void setCOLUMN_6(String COLUMN_6) {
        this.COLUMN_6 = COLUMN_6;
    }
}
