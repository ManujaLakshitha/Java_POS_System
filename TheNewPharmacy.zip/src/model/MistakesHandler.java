package model;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class MistakesHandler {

    public static boolean isNumeric(String strNum) {
        if (strNum == null) {
            return false;
        }
        try {
            double d = Double.parseDouble(strNum);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    public static double numericsMistakesHandler(JTextField component) {

        double filteredValue = 0;
        String value = component.getText();

        if (component.isFocusOwner()) {
            //focus gain
            component.setBorder(new LineBorder(new Color(240, 120, 8), 2));
            if (value.isEmpty()) {
                component.setBorder(new LineBorder(Color.RED, 2));
            } else {
                if (value.equals("0")) {
                    component.setText("0.00");
                    component.selectAll();
                } else if (MistakesHandler.isNumeric(value)) {
                    filteredValue = Double.parseDouble(value);
                } else {
                    component.setText("0.00");
                    component.selectAll();
                }
            }

        } else {
            //focus out
            component.setBorder(new LineBorder(new Color(200, 200, 200), 1));
            if (value.isEmpty()) {
                component.setText("0.00");
            } else {
                if (value.equals("0.00")) {
                    component.setText("0.00");
                } else {
                    boolean isInt = false;
                    try {
                        int v = Integer.parseInt(value);
                        isInt = true;
                    } catch (Exception e) {
                    }
                    if (isInt) {
                        component.setText(component.getText() + ".00");
                    }
                }
            }
        }

        return filteredValue;
    }
}
