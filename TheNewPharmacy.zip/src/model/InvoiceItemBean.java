package model;

public class InvoiceItemBean {
    private String index;
    private String name;
    private String qtyAndRate;
    private String itemTotal;

    /**
     * @return the index
     */
    public String getIndex() {
        return index;
    }

    /**
     * @param index the index to set
     */
    public void setIndex(String index) {
        this.index = index;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the qtyAndRate
     */
    public String getQtyAndRate() {
        return qtyAndRate;
    }

    /**
     * @param qtyAndRate the qtyAndRate to set
     */
    public void setQtyAndRate(String qtyAndRate) {
        this.qtyAndRate = qtyAndRate;
    }
    
    /**
     * @return the itemTotal
     */
    public String getItemTotal() {
        return itemTotal;
    }

    /**
     * @param itemTotal the itemTotal to set
     */
    public void setItemTotal(String itemTotal) {
        this.itemTotal = itemTotal;
    }
}
