/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gui;

import com.formdev.flatlaf.intellijthemes.FlatArcOrangeIJTheme;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import model.PaymentBean;
import model.SQL;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;

public class SupplierPaymentReport extends javax.swing.JFrame {

    private DefaultTableModel model;

    private double TotalCost = 0;
    private double TotalPaid = 0;

    private void printReport(){

        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

//        String path = "src//reports//SupplierPaymentReport.jasper";
      
        HashMap<String, Object> parameters = new HashMap();

        parameters.put("Title", "Monthly Sales Report");
        parameters.put("Duration", "For");
        parameters.put("Duration1", String.valueOf(yearPicker.getSelectedItem()) + "/" + String.valueOf(monthPicker.getSelectedItem()));
        parameters.put("ReportedDate", format.format(date));

        parameters.put("TotalCost", String.valueOf(this.TotalCost));
        parameters.put("TotalPaid", String.valueOf(this.TotalPaid));
        parameters.put("TotalDue", String.valueOf(this.TotalPaid - this.TotalCost));

        try {

            Vector v = new Vector();

            for (int i = 0; i < jTable1.getRowCount(); i++) {
                PaymentBean bean = new PaymentBean();
                bean.setCOLUMN_0(String.valueOf(jTable1.getValueAt(i, 0)));
                bean.setCOLUMN_1(String.valueOf(jTable1.getValueAt(i, 1)));
                bean.setCOLUMN_2(String.valueOf(jTable1.getValueAt(i, 2)));
                bean.setCOLUMN_3(String.valueOf(jTable1.getValueAt(i, 3)));
                bean.setCOLUMN_4(String.valueOf(jTable1.getValueAt(i, 4)));
                bean.setCOLUMN_5(String.valueOf(jTable1.getValueAt(i, 5)));
                bean.setCOLUMN_6(String.valueOf(jTable1.getValueAt(i, 6)));

                v.add(bean);
            }
            
            URL reportPath = getClass().getResource("/reports/SupplierPaymentsReport.jasper");
            String path = Paths.get(reportPath.toURI()).toString();

            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(v);

            JasperPrint report = JasperFillManager.fillReport(path, parameters, dataSource);
            JasperViewer.viewReport(report, false);
        } catch (Exception e) {
            Logger logger = SignIn.log1;
            logger.warning(e.toString());
        }
    }

    private void saveReport(){
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

//        String path = "src//reports//SupplierPaymentReport.jasper";
        

        HashMap<String, Object> parameters = new HashMap();

        parameters.put("Title", "Monthly Sales Report");
        parameters.put("Duration", "For");
        parameters.put("Duration1", String.valueOf(yearPicker.getSelectedItem()) + "/" + String.valueOf(monthPicker.getSelectedItem()));
        parameters.put("ReportedDate", format.format(date));

        parameters.put("TotalCost", String.valueOf(this.TotalCost));
        parameters.put("TotalPaid", String.valueOf(this.TotalPaid));
        parameters.put("TotalDue", String.valueOf(this.TotalPaid - this.TotalCost));

        try {

            Vector v = new Vector();

            for (int i = 0; i < jTable1.getRowCount(); i++) {
                PaymentBean bean = new PaymentBean();
                bean.setCOLUMN_0(String.valueOf(jTable1.getValueAt(i, 0)));
                bean.setCOLUMN_1(String.valueOf(jTable1.getValueAt(i, 1)));
                bean.setCOLUMN_2(String.valueOf(jTable1.getValueAt(i, 2)));
                bean.setCOLUMN_3(String.valueOf(jTable1.getValueAt(i, 3)));
                bean.setCOLUMN_4(String.valueOf(jTable1.getValueAt(i, 4)));
                bean.setCOLUMN_5(String.valueOf(jTable1.getValueAt(i, 5)));
                bean.setCOLUMN_6(String.valueOf(jTable1.getValueAt(i, 6)));

                v.add(bean);
            }
            
            URL reportPath = getClass().getResource("reports/SupplierPaymentsReport.jasper");
            String path = Paths.get(reportPath.toURI()).toString();

            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(v);

            JasperPrint report = JasperFillManager.fillReport(path, parameters, dataSource);
            JasperExportManager.exportReportToPdfFile(report, "Report_" + System.currentTimeMillis() + ".pdf");
        } catch (Exception e) {
            Logger logger = SignIn.log1;
            logger.warning(e.toString());
        }
    }

    private void reset() {

        LocalDate currentDate = LocalDate.now();
        int currentYear = currentDate.getYear();
        yearPicker.setSelectedItem(String.valueOf(currentYear));
        monthPicker.setSelectedItem("05");
    }

    private void dataLoading() {

        this.TotalCost = 0;
        this.TotalPaid = 0;

        String year = String.valueOf(yearPicker.getSelectedItem());
        String month = String.valueOf(monthPicker.getSelectedItem());

        this.model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        try {
            ResultSet rs = SQL.execute("SELECT * FROM `grn` INNER JOIN `supplier` ON `grn`.`supplier_mobile`=`supplier`.`mobile` WHERE `grn`.`date` LIKE '" + year + "-" + month + "%'");
            while (rs.next()) {
                Vector v = new Vector();

                v.add(rs.getString("grn_id"));
                v.add(rs.getString("date"));
                v.add(rs.getString("mobile"));
                v.add(rs.getString("fname") + " " + rs.getString("lname"));
                v.add(rs.getString("total"));
                v.add(rs.getString("paid"));

                double paid = Double.parseDouble(rs.getString("paid"));
                double total = Double.parseDouble(rs.getString("total"));

                this.TotalPaid += paid;
                this.TotalCost += total;

                v.add(paid - total);

                this.model.addRow(v);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public SupplierPaymentReport() {
        initComponents();
        reset();
        dataLoading();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        yearPicker = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        monthPicker = new javax.swing.JComboBox<>();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel1.setText("Supplier Payment Report");

        jLabel2.setText("Year");

        yearPicker.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2024", "2023" }));

        jLabel3.setText("Month");

        monthPicker.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));
        monthPicker.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                monthPickerActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 0, 0));
        jButton3.setText("jButton3");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("FIND");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("CLEAR");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addGap(49, 49, 49)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(yearPicker, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(monthPicker, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 42, Short.MAX_VALUE)
                .addComponent(jButton5)
                .addGap(40, 40, 40)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(yearPicker, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(monthPicker, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        jPanel2.setLayout(new java.awt.BorderLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "GRN No", "Date", "Mobile", "Supplier Name", "Total", "Paid", "Due"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(200);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(6).setResizable(false);
        }

        jPanel2.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jButton1.setText("PRINT REPORT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("SAVE REPORT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        printReport();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void monthPickerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_monthPickerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_monthPickerActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        dataLoading();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        reset();
        dataLoading();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        saveReport();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        FlatArcOrangeIJTheme.setup();

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SupplierPaymentReport().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> monthPicker;
    private javax.swing.JComboBox<String> yearPicker;
    // End of variables declaration//GEN-END:variables
}
