package gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import model.InvoiceItemBean;
import model.InvoiceProductBean;
import model.MistakesHandler;
import model.SQL;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

public class InvoicePanel extends javax.swing.JPanel {

    private InvoiceProductBean invoiceProductBean;
    private InvoiceViewPanel invoicePreview;
    private InvoiceAddCustomer invoiceAddCustomer;

    private boolean isBarcodeFocused = true;

    //usage for single product adding 
    private int enteredQty;
    private double singProductTotal;

    //usage for total related calculations
    private double totalPrice;

    private HashMap<String, Object> pm_map;
    private HashMap<String, String> barcodeMap;

    private double netTotal;
    private double discount;
    private double tax;
    private double paid;
    private double balance;
    private int selectedRow;
    private String selectedRowValue;
    private String selectedRowPrice;
    public String today;

    //-------------------Code optimization start--------------------//
    //-------------------Code optimization end--------------------//
    private void shortKeysSetter() {
        try {
            URL reportPath1 = getClass().getResource("/resource/closeBtn.png");
            String image1 = Paths.get(reportPath1.toURI()).toString();
            URL reportPath2 = getClass().getResource("/resource/shortKey.png");
            String image2 = Paths.get(reportPath2.toURI()).toString();
            URL reportPath3 = getClass().getResource("/resource/printIcon.png");
            String image3 = Paths.get(reportPath3.toURI()).toString();
            URL reportPath4 = getClass().getResource("/resource/newPageIcon.png");
            String image4 = Paths.get(reportPath4.toURI()).toString();
            URL reportPath5 = getClass().getResource("/resource/pdfIcon.png");
            String image5 = Paths.get(reportPath5.toURI()).toString();
            URL reportPath6 = getClass().getResource("/resource/payDueIcon.png");
            String image6 = Paths.get(reportPath6.toURI()).toString();
            URL reportPath7 = getClass().getResource("/resource/returnIcon.png");
            String image7 = Paths.get(reportPath7.toURI()).toString();
            URL reportPath8 = getClass().getResource("/resource/searchIcon.png");
            String image8 = Paths.get(reportPath8.toURI()).toString();

            jLabel33.setBackground(new Color(0, 0, 0, 0));
            jLabel33.setIcon(new ImageIcon(new ImageIcon(image1).getImage().getScaledInstance(25, 25, 1)));
            jLabel34.setBackground(new Color(0, 0, 0, 0));
            jLabel34.setIcon(new ImageIcon(new ImageIcon(image2).getImage().getScaledInstance(25, 25, 1)));
            jLabel35.setBackground(new Color(0, 0, 0, 0));
            jLabel35.setIcon(new ImageIcon(new ImageIcon(image3).getImage().getScaledInstance(25, 25, 1)));
            jLabel36.setBackground(new Color(0, 0, 0, 0));
            jLabel36.setIcon(new ImageIcon(new ImageIcon(image4).getImage().getScaledInstance(25, 25, 1)));
            jLabel37.setBackground(new Color(0, 0, 0, 0));
            jLabel37.setIcon(new ImageIcon(new ImageIcon(image5).getImage().getScaledInstance(25, 25, 1)));
            jLabel38.setBackground(new Color(0, 0, 0, 0));
            jLabel38.setIcon(new ImageIcon(new ImageIcon(image6).getImage().getScaledInstance(25, 25, 1)));
            jLabel39.setBackground(new Color(0, 0, 0, 0));
            jLabel39.setIcon(new ImageIcon(new ImageIcon(image7).getImage().getScaledInstance(25, 25, 1)));
            jLabel40.setBackground(new Color(0, 0, 0, 0));
            jLabel40.setIcon(new ImageIcon(new ImageIcon(image8).getImage().getScaledInstance(25, 25, 1)));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//done

    private void loadPaymentMethods() {
        try {
            ResultSet rs = SQL.execute("SELECT * FROM `payment_method`");

            Vector v = new Vector();
            pm_map = new HashMap();

            while (rs.next()) {
                v.add(rs.getString("method"));
                pm_map.put(rs.getString("method"), rs.getInt("id"));
            }

            DefaultComboBoxModel comboBoxModel = new DefaultComboBoxModel(v);
            pmField.setModel(comboBoxModel);
            pmField.setSelectedItem("Cash");

        } catch (Exception e) {
            Logger logger = SignIn.log1;
            logger.warning(e.toString());
        }
    }//done

    private void timeSetter() {

        Thread t = new Thread(() -> {

            while (true) {
                java.util.Date date = new java.util.Date();
                SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
                String currentDateTime = format1.format(date);
                jLabel23.setText(currentDateTime);
                invoicePreview.date.setText(currentDateTime);

                try {
                    Thread.sleep(1000);
                } catch (Exception e) {
                    Logger logger = SignIn.log1;
                    logger.warning(e.toString());
                }
            }
        });
        t.start();
    }

    public void setInvoiceUser() {

        String fname = SignIn.userBean.getFname();
        String newFname = fname.substring(0, 1).toUpperCase() + fname.substring(1, 5);
        jLabel22.setText(newFname);
        invoicePreview.cashier.setText(newFname);

    }//done

    public void fullClear() {
        //fields
        barCode.setText("");
        productCombo.setText("");
        productName.setText("");
        qty.setText("0");
        salePrice.setText("0.00");
        singleProductTotal.setText("0.00");
        jLabel17.setText("0");
        selectedRow = 0;
        selectedRowValue = "";
        selectedRowPrice = "";
        paidField.setText("0.00");
        availableQty.setText("");
        availableQty.setOpaque(false);
        totalField.setText("0.00");
        discountField.setText("0.00");
        taxField.setText("0.00");
        netTotalField.setText("0.00");
        balanceField.setText("0.00");

        //instance variables
        enteredQty = 0;
        singProductTotal = 0;
        totalPrice = 0;
        discount = 0;
        tax = 0;
        netTotal = 0;
        loadPaymentMethods();
        paid = 0;
        balance = 0;

        jPanel9.removeAll();
        invoiceProductBean = null;
        this.barcodeMap = null;
        invoicePreview = new InvoiceViewPanel();
        invoiceAddCustomer = new InvoiceAddCustomer();
        jPanel9.add(invoicePreview);
        jPanel9.add(invoiceAddCustomer);

        DefaultTableModel model = (DefaultTableModel) itemsTable.getModel();
        model.setRowCount(0);
        tableTotalCalcuate();
        focusBarcodeField();
        setInvoiceUser();

        java.util.Date date = new java.util.Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        today = format.format(date);

        SwingUtilities.updateComponentTreeUI(jPanel9);

        disableCalcFields();
    }

    private void findProduct(String barcode) {
        this.barCode.setText("");
        this.productCombo.setText("");

        try {

            ResultSet resultSet = SQL.execute("SELECT * FROM `pharmacy_db`.`stock` "
                    + "INNER JOIN `pharmacy_db`.`product` ON `pharmacy_db`.`stock`.`product_id`=`pharmacy_db`.`product`.`id` "
                    + "INNER JOIN `pharmacy_db`.`brand` ON `pharmacy_db`.`product`.`brand_id`=`pharmacy_db`.`brand`.`id` WHERE `pharmacy_db`.`stock`.`barcode`='" + barcode + "' AND `pharmacy_db`.`product`.`status`='1'");

            if (resultSet.next()) {

                invoiceProductBean = new InvoiceProductBean();
                invoiceProductBean.setBarcode(resultSet.getInt("stock.barcode"));
                invoiceProductBean.setBrand(resultSet.getString("brand.name"));
                invoiceProductBean.setQuantity(resultSet.getInt("stock.qty"));
                invoiceProductBean.setSellingPrice(resultSet.getDouble("stock.selling_price"));
                invoiceProductBean.setName(resultSet.getString("product.name"));
                invoiceProductBean.setDescription(resultSet.getString("product.description"));

                descriptionField.setText(String.valueOf(resultSet.getString("product.description")));

                availableQty.setText(String.valueOf(invoiceProductBean.getQuantity()));
                availableQty.setOpaque(true);
                if (invoiceProductBean.getQuantity() < 1) {
                    availableQty.setBackground(Color.red);
                } else if (invoiceProductBean.getQuantity() >= 1 && invoiceProductBean.getQuantity() <= 5) {
                    availableQty.setBackground(Color.ORANGE);
                } else {
                    availableQty.setBackground(new Color(51, 180, 0));
                }

                this.enteredQty = 1;
                this.qty.setText(String.valueOf(enteredQty));

                if (isBarcodeFocused) {
                    singleTotalSetter();
                    addItemToTable();
                } else {
                    this.qty.setEditable(true);
                    this.qty.grabFocus();
                    singleTotalSetter();
                }

                // create a string
                String message = invoiceProductBean.getBrand() + " " + invoiceProductBean.getName();

                // stores each characters to a char array
                char[] charArray = message.toCharArray();
                boolean foundSpace = true;

                for (int i = 0; i < charArray.length; i++) {

                    // if the array element is a letter
                    if (Character.isLetter(charArray[i])) {

                        // check space is present before the letter
                        if (foundSpace) {

                            // change the letter into uppercase
                            charArray[i] = Character.toUpperCase(charArray[i]);
                            foundSpace = false;
                        }
                    } else {
                        // if the new character is not character
                        foundSpace = true;
                    }
                }

                // convert the char array to the string
                message = String.valueOf(charArray);
                productName.setText(message);

                salePrice.setText(String.valueOf(invoiceProductBean.getSellingPrice() + "0"));
            }

        } catch (Exception e) {
            Logger logger = SignIn.log1;
            logger.warning(e.toString());
        }
    } //done

    private void singleTotalSetter() {
        double total = invoiceProductBean.getSellingPrice() * enteredQty;
        singProductTotal = total;
        this.singleProductTotal.setText(String.valueOf(singProductTotal + "0"));
    }//done

    private void tableTotalCalcuate() {

        int rowCount = itemsTable.getRowCount();

        double t = 0;
        int q = 0;

        for (int i = 0; i < rowCount; i++) {

            String rowTotalPrice = String.valueOf(itemsTable.getValueAt(i, 4));
            String qty = String.valueOf(itemsTable.getValueAt(i, 2));

            t += Double.parseDouble(rowTotalPrice);
            q += Integer.parseInt(qty);

        }

        this.totalPrice = t;
        this.netTotal = t;

        invoicePreview.totalItems.setText(String.valueOf(q));
        jLabel7.setText(String.valueOf(q));

        totalField.setText(String.valueOf(t));
        netTotalField.setText(String.valueOf(t));

        loopDetailBand();
        calculate();

    }//done

    private void addItemToTable() {

        if (barcodeMap == null) {
            this.barcodeMap = new HashMap();
        }

        if (invoiceProductBean != null) {

            boolean found = false;

            for (int i = 0; i < this.itemsTable.getRowCount(); i++) {

                String index = String.valueOf(itemsTable.getValueAt(i, 0));
                String barcodeOfTableItem = String.valueOf(barcodeMap.get(index));

                if (barcodeOfTableItem.equals(String.valueOf(invoiceProductBean.getBarcode()))) {

                    String qty2 = String.valueOf(itemsTable.getValueAt(i, 2));
                    String unitPrice = String.valueOf(itemsTable.getValueAt(i, 3));

                    itemsTable.setValueAt(Integer.parseInt(qty2) + enteredQty, i, 2);
                    itemsTable.setValueAt((Integer.parseInt(qty2) + enteredQty) * Double.parseDouble(unitPrice), i, 4);

                    found = true;
                    break;
                }

            }

            if (!found) {

                DefaultTableModel tableModel = (DefaultTableModel) itemsTable.getModel();
                Vector vector = new Vector();

                int index = itemsTable.getRowCount() + 1;
                barcodeMap.put(String.valueOf(index), String.valueOf(invoiceProductBean.getBarcode()));

                vector.add(index);
                vector.add(invoiceProductBean.getName());
                vector.add(this.enteredQty);
                vector.add(invoiceProductBean.getSellingPrice());
                vector.add(this.singProductTotal);

                tableModel.addRow(vector);
            }

            enableCalcFields();
            tableTotalCalcuate();
            calculate();

        }
    }//done

    private void focusBarcodeField() {
        this.barCode.setEnabled(true);
        this.productCombo.setEnabled(false);
        this.qty.setEditable(false);
        isBarcodeFocused = true;
        barCode.grabFocus();
    } //done

    private void focusProductField() {
        this.productCombo.setEnabled(true);
        this.barCode.setEnabled(false);
        qty.setEditable(false);
        productCombo.grabFocus();
        isBarcodeFocused = false;
    }//done

    private void disableCalcFields() {
        discountField.setEditable(false);
        taxField.setEditable(false);
        paidField.setEditable(false);
        pmField.setEnabled(false);
    }//done

    private void enableCalcFields() {
        discountField.setEditable(true);
        taxField.setEditable(true);
        paidField.setEditable(true);
        pmField.setEnabled(true);
    }//done

    private void calculate() {

        if (pmField.getSelectedItem().equals("Cash")) {

            netTotal = (this.totalPrice - this.discount) + tax;
            balance = paid - netTotal;

            invoicePreview.billTotal.setText(String.valueOf(this.totalPrice));
            invoicePreview.billDis.setText(String.valueOf(this.discount));
            invoicePreview.billTax.setText(String.valueOf(this.tax));
            invoicePreview.billPaid.setText(String.valueOf(this.paid));

            if (!paidField.isEditable()) {
                paidField.setEditable(true);
                invoicePreview.billPaid.setText("0.00");
                paidField.setText("0.00");
            }

            netTotalField.setText(String.valueOf(netTotal));
            invoicePreview.billNet.setText(String.valueOf(netTotal));

            balanceField.setText(String.valueOf(balance));
            invoicePreview.billBal.setText(String.valueOf(balance));

        } else if (pmField.getSelectedItem().equals("Card")) {

            netTotal = (this.totalPrice - this.discount) + tax;
            paidField.setEditable(false);

            paidField.setText(String.valueOf(netTotal));
            invoicePreview.billPaid.setText(String.valueOf(netTotal));

            netTotalField.setText(String.valueOf(netTotal));
            balanceField.setText("0.00");
            invoicePreview.billBal.setText("0.00");

        }
    }//done

    private void loopDetailBand() {
        invoicePreview.detailBand.removeAll();
        int count = itemsTable.getRowCount();
        for (int i = 0; i < count; i++) {
            String index = String.valueOf(itemsTable.getValueAt(i, 0));
            String name = String.valueOf(itemsTable.getValueAt(i, 1));
            String qty = String.valueOf(itemsTable.getValueAt(i, 2));
            String unitPrice = String.valueOf(itemsTable.getValueAt(i, 3));
            String total = String.valueOf(itemsTable.getValueAt(i, 4));

            InvoiceItem invoiceItem = new InvoiceItem();
            invoiceItem.itemNo.setText(index);
            invoiceItem.name.setText(name);
            invoiceItem.qtyAndRate.setText(String.valueOf(qty + " * " + unitPrice));
            invoiceItem.total.setText(total);

            invoicePreview.detailBand.add(invoiceItem);
            SwingUtilities.updateComponentTreeUI(invoicePreview);
        }
    }

    private void completeInvoice() {

        if (itemsTable.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please select a product", "Warning", JOptionPane.WARNING_MESSAGE);
        } else if (Double.parseDouble(balanceField.getText()) >= 0) {

            int option = JOptionPane.showConfirmDialog(this, "Do you want to continue ?", "Confirmation Message", JOptionPane.YES_NO_OPTION);

            if (option == JOptionPane.YES_OPTION) {

                String invoiceId = SignIn.userBean.getUserId() + "" + System.currentTimeMillis();

                try {
                    String pm_id = String.valueOf(pm_map.get(pmField.getSelectedItem()));

                    HashMap<String, Object> map = new HashMap();

                    SQL.execute("INSERT INTO `pharmacy_db`.`invoice` (`invoice_id`,`date`,`total`,`tax`,`discount`,`paid`,`customer_mobile`,`payment_method_id`)"
                            + " VALUES ('" + invoiceId + "','" + today + "','" + totalField.getText() + "','" + tax + "','" + discount + "','" + paid + "','none','" + pm_id + "')");

                    Vector vector = new Vector();
                    int q = 0;

                    for (int i = 0; i < itemsTable.getRowCount(); i++) {
                        SQL.execute("INSERT INTO `pharmacy_db`.`invoice_item` (`qty`,`invoice_id`,`stock_barcode`) VALUES "
                                + "('" + String.valueOf(itemsTable.getValueAt(i, 2)) + "','" + invoiceId + "','" + barcodeMap.get(String.valueOf(itemsTable.getValueAt(i, 0))) + "')");
                        SQL.execute("UPDATE `stock` SET `qty` = `qty`-" + String.valueOf(itemsTable.getValueAt(i, 2)) + " WHERE `barcode`='" + barcodeMap.get(String.valueOf(itemsTable.getValueAt(i, 0))) + "' ");

                        //-------report printing-------//
                        InvoiceItemBean itemBean = new InvoiceItemBean();
                        itemBean.setIndex(String.valueOf(itemsTable.getValueAt(i, 0)));
                        itemBean.setName(String.valueOf(itemsTable.getValueAt(i, 1)));
                        itemBean.setQtyAndRate(String.valueOf(itemsTable.getValueAt(i, 2) + " * " + itemsTable.getValueAt(i, 3)));
                        itemBean.setItemTotal(String.valueOf(itemsTable.getValueAt(i, 4)));

                        vector.add(itemBean);

                        q += Integer.parseInt(String.valueOf(itemsTable.getValueAt(i, 2)));
                        //-------report printing-------//
                    }

                    map.put("co", String.valueOf(q));
                    map.put("date", today);
                    map.put("cashier", SignIn.userBean.getFname().toUpperCase());
                    map.put("no", invoiceId);

                    map.put("total", totalField.getText());
                    map.put("discount", discountField.getText());
                    map.put("tax", taxField.getText());
                    map.put("netTotal", netTotalField.getText());
                    map.put("paid", paidField.getText());
                    map.put("balance", balanceField.getText());

                    JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(vector);

//                    String path = "src//reports//invoicePrintOut.jasper";
                    URL reportPath1 = getClass().getResource("/reports/invoicePrintOut.jasper");
                    String path = Paths.get(reportPath1.toURI()).toString();

                    JasperPrint report = JasperFillManager.fillReport(path, map, dataSource);

                    fullClear();
                    try {
                        ConfirmPaperPrint p = new ConfirmPaperPrint(Dashboard.invoice, true, report, invoiceId);
                        p.setVisible(true);

                    } catch (Exception e) {
                        Logger logger = SignIn.log1;
                        logger.warning(e.toString());
                    }

                } catch (Exception e) {
                    Logger logger = SignIn.log1;
                    logger.warning(e.toString());
                }

            }

        } else {
            JOptionPane.showMessageDialog(this, "Your payment is not enough", "Warning", JOptionPane.WARNING_MESSAGE);
        }

    }

    public InvoicePanel() { //done
        initComponents();

        invoicePreview = new InvoiceViewPanel();
        invoiceAddCustomer = new InvoiceAddCustomer();
        jPanel9.add(invoicePreview);
        jPanel9.add(invoiceAddCustomer);

        focusBarcodeField();
        shortKeysSetter();
        loadPaymentMethods();
        disableCalcFields();
        timeSetter();
        setInvoiceUser();

        jTextField1.setVisible(false);
        clearBtn2.setVisible(false);
        jPanel5.setMinimumSize(new Dimension(100, 100));

        java.util.Date date = new java.util.Date();
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
        today = format1.format(date);

        JScrollBar verticalScrollBar = new JScrollBar() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(0, 0);
            }
        };

        jScrollPane3.setVerticalScrollBar(verticalScrollBar);
        jPanel9.setMaximumSize(new Dimension(500, 437));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel21 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        barCode = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        productName = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        qty = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        salePrice = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        singleProductTotal = new javax.swing.JTextField();
        availableQty = new javax.swing.JLabel();
        productCombo = new javax.swing.JTextField();
        clearBtn = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        itemsTable = new javax.swing.JTable();
        jPanel6 = new javax.swing.JPanel();
        invField = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        pmField = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        discountField = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        netTotalField = new javax.swing.JTextField();
        paidField = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        totalField = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        taxField = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        balanceField = new javax.swing.JTextField();
        jPanel14 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel29 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jPanel28 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jPanel29 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jPanel30 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        clearBtn2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jPanel13 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel32 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel33 = new javax.swing.JPanel();
        jPanel34 = new javax.swing.JPanel();
        jPanel35 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        descriptionField = new javax.swing.JTextArea();
        jPanel8 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jPanel9 = new javax.swing.JPanel();

        javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
        jPanel21.setLayout(jPanel21Layout);
        jPanel21Layout.setHorizontalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel21Layout.setVerticalGroup(
            jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel20.setText("jLabel20");

        jPanel1.setBorder(javax.swing.BorderFactory.createMatteBorder(0, 0, 0, 1, new java.awt.Color(204, 204, 204)));
        jPanel1.setPreferredSize(new java.awt.Dimension(500, 683));

        jPanel2.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jPanel2.setOpaque(false);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel1.setText("Scanner Code");
        jLabel1.setPreferredSize(new java.awt.Dimension(42, 30));

        barCode.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        barCode.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                barCodeMouseClicked(evt);
            }
        });
        barCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                barCodeKeyReleased(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel2.setText("Product");

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel3.setText("Selected Product");

        productName.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        productName.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 7, 0, 0));
        productName.setOpaque(true);

        jLabel5.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel5.setText("Quantity");

        qty.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        qty.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        qty.setText("0");
        qty.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                qtyFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                qtyFocusLost(evt);
            }
        });
        qty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                qtyActionPerformed(evt);
            }
        });
        qty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                qtyKeyReleased(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel6.setText("Sale Price");

        salePrice.setEditable(false);
        salePrice.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        salePrice.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        salePrice.setText("0.00");
        salePrice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salePriceActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel10.setText("Total");

        singleProductTotal.setEditable(false);
        singleProductTotal.setBackground(new java.awt.Color(204, 204, 204));
        singleProductTotal.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        singleProductTotal.setForeground(new java.awt.Color(51, 51, 51));
        singleProductTotal.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        singleProductTotal.setText("0.00");

        availableQty.setBackground(new java.awt.Color(51, 180, 0));
        availableQty.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        availableQty.setForeground(new java.awt.Color(255, 255, 255));
        availableQty.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        productCombo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                productComboMouseClicked(evt);
            }
        });
        productCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productComboActionPerformed(evt);
            }
        });
        productCombo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                productComboKeyReleased(evt);
            }
        });

        clearBtn.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        clearBtn.setForeground(new java.awt.Color(240, 120, 8));
        clearBtn.setText("CLEAR");
        clearBtn.setPreferredSize(new java.awt.Dimension(100, 23));
        clearBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(productName, javax.swing.GroupLayout.PREFERRED_SIZE, 775, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(barCode)
                    .addComponent(productCombo)))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(qty, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(availableQty, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(salePrice, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(80, 80, 80)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(singleProductTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(barCode, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(productCombo, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                    .addComponent(productName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(salePrice, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(availableQty, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(qty, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(clearBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(singleProductTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setLayout(new java.awt.BorderLayout());

        jPanel5.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 10, 10));
        jPanel5.setPreferredSize(new java.awt.Dimension(464, 439));

        itemsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Index", "Product", "Quantity", "Unit Price", "Line Total", "Action"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        itemsTable.setMinimumSize(new java.awt.Dimension(105, 120));
        itemsTable.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                itemsTableFocusLost(evt);
            }
        });
        itemsTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemsTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(itemsTable);
        if (itemsTable.getColumnModel().getColumnCount() > 0) {
            itemsTable.getColumnModel().getColumn(0).setResizable(false);
            itemsTable.getColumnModel().getColumn(0).setPreferredWidth(10);
            itemsTable.getColumnModel().getColumn(1).setResizable(false);
            itemsTable.getColumnModel().getColumn(1).setPreferredWidth(300);
            itemsTable.getColumnModel().getColumn(2).setResizable(false);
            itemsTable.getColumnModel().getColumn(2).setPreferredWidth(10);
            itemsTable.getColumnModel().getColumn(3).setResizable(false);
            itemsTable.getColumnModel().getColumn(3).setPreferredWidth(20);
            itemsTable.getColumnModel().getColumn(4).setResizable(false);
            itemsTable.getColumnModel().getColumn(4).setPreferredWidth(20);
            itemsTable.getColumnModel().getColumn(5).setResizable(false);
            itemsTable.getColumnModel().getColumn(5).setPreferredWidth(10);
        }

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 909, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        invField.setEditable(false);
        invField.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        invField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        invField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                invFieldActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel13.setText("INV No");

        pmField.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        pmField.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                pmFieldItemStateChanged(evt);
            }
        });
        pmField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                pmFieldKeyReleased(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel14.setText("Discount");

        discountField.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        discountField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        discountField.setText("0.00");
        discountField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                discountFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                discountFieldFocusLost(evt);
            }
        });
        discountField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                discountFieldActionPerformed(evt);
            }
        });
        discountField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                discountFieldKeyReleased(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel15.setText("Net Total");

        netTotalField.setEditable(false);
        netTotalField.setBackground(new java.awt.Color(240, 120, 8));
        netTotalField.setFont(new java.awt.Font("Helvetica Neue", 1, 16)); // NOI18N
        netTotalField.setForeground(new java.awt.Color(255, 255, 255));
        netTotalField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        netTotalField.setText("0.00");
        netTotalField.setPreferredSize(new java.awt.Dimension(64, 118));

        paidField.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        paidField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        paidField.setText("0.00");
        paidField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                paidFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                paidFieldFocusLost(evt);
            }
        });
        paidField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                paidFieldActionPerformed(evt);
            }
        });
        paidField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                paidFieldKeyReleased(evt);
            }
        });

        jLabel17.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel17.setText("Tax");

        jLabel16.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel16.setText("Paid");

        jButton3.setFont(new java.awt.Font("Helvetica Neue", 1, 16)); // NOI18N
        jButton3.setForeground(new java.awt.Color(51, 180, 0));
        jButton3.setText("PRINT");
        jButton3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 180, 0), 2));
        jButton3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jButton3FocusLost(evt);
            }
        });
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jButton3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jButton3KeyReleased(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel18.setText("Total");

        totalField.setEditable(false);
        totalField.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        totalField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        totalField.setText("0.00");

        jLabel11.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel11.setText("Type");

        taxField.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        taxField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        taxField.setText("0.00");
        taxField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                taxFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                taxFieldFocusLost(evt);
            }
        });
        taxField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                taxFieldActionPerformed(evt);
            }
        });
        taxField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                taxFieldKeyReleased(evt);
            }
        });

        jLabel12.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel12.setText("Balance");

        balanceField.setEditable(false);
        balanceField.setFont(new java.awt.Font("Helvetica Neue", 1, 16)); // NOI18N
        balanceField.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        balanceField.setText("0.00");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(invField, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(netTotalField, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(totalField, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pmField, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(discountField, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(paidField, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(taxField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(balanceField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(invField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(totalField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(discountField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(taxField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(netTotalField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(paidField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(pmField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(balanceField))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        jLabel16.getAccessibleContext().setAccessibleName("");
        jLabel18.getAccessibleContext().setAccessibleName("");

        jPanel14.setBackground(new java.awt.Color(230, 230, 230));
        jPanel14.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));
        jPanel14.setLayout(new java.awt.GridLayout(1, 8, 10, 0));

        jPanel15.setLayout(new java.awt.BorderLayout());

        jLabel25.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("CLOSE");
        jPanel15.add(jLabel25, java.awt.BorderLayout.PAGE_END);

        jLabel33.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setText("[F1]");
        jPanel15.add(jLabel33, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel15);

        jPanel16.setLayout(new java.awt.BorderLayout());

        jLabel27.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText("SHORTCUTS");
        jPanel16.add(jLabel27, java.awt.BorderLayout.PAGE_END);

        jLabel34.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("[F2]");
        jPanel16.add(jLabel34, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel16);

        jPanel17.setLayout(new java.awt.BorderLayout());

        jLabel28.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("PRINT");
        jPanel17.add(jLabel28, java.awt.BorderLayout.PAGE_END);

        jLabel35.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText("[F3]");
        jPanel17.add(jLabel35, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel17);

        jPanel18.setLayout(new java.awt.BorderLayout());

        jLabel29.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("NEW");
        jPanel18.add(jLabel29, java.awt.BorderLayout.PAGE_END);

        jLabel36.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setText("[F4]");
        jPanel18.add(jLabel36, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel18);

        jPanel19.setLayout(new java.awt.BorderLayout());

        jLabel30.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText("PDF");
        jPanel19.add(jLabel30, java.awt.BorderLayout.PAGE_END);

        jLabel37.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel37.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel37.setText("[F5]");
        jPanel19.add(jLabel37, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel19);

        jPanel28.setLayout(new java.awt.BorderLayout());

        jLabel31.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setText("PAY DUE");
        jPanel28.add(jLabel31, java.awt.BorderLayout.PAGE_END);

        jLabel38.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel38.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel38.setText("[F5]");
        jPanel28.add(jLabel38, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel28);

        jPanel29.setLayout(new java.awt.BorderLayout());

        jLabel32.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("RETURN");
        jPanel29.add(jLabel32, java.awt.BorderLayout.PAGE_END);

        jLabel39.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel39.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel39.setText("[F5]");
        jPanel29.add(jLabel39, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel29);

        jPanel30.setLayout(new java.awt.BorderLayout());

        jLabel24.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("SERACH");
        jPanel30.add(jLabel24, java.awt.BorderLayout.PAGE_END);

        jLabel40.setFont(new java.awt.Font("Helvetica Neue", 0, 15)); // NOI18N
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel40.setText("[F5]");
        jPanel30.add(jLabel40, java.awt.BorderLayout.CENTER);

        jPanel14.add(jPanel30);

        jPanel11.setBorder(javax.swing.BorderFactory.createEmptyBorder(0, 10, 0, 10));

        jLabel4.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel4.setText("Total Items");

        jLabel7.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(240, 120, 8));
        jLabel7.setText("0");

        clearBtn2.setBackground(new java.awt.Color(255, 0, 0));
        clearBtn2.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        clearBtn2.setForeground(new java.awt.Color(255, 255, 255));
        clearBtn2.setText("REMOVE");
        clearBtn2.setPreferredSize(new java.awt.Dimension(100, 23));
        clearBtn2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clearBtn2MouseClicked(evt);
            }
        });
        clearBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearBtn2ActionPerformed(evt);
            }
        });

        jTextField1.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextField1FocusLost(evt);
            }
        });
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jTextField1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField1KeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(475, 475, 475)
                .addComponent(clearBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 929, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, 226, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        jPanel13.setBorder(javax.swing.BorderFactory.createMatteBorder(1, 0, 0, 0, new java.awt.Color(204, 204, 204)));
        jPanel13.setLayout(new java.awt.GridLayout(1, 5));

        jLabel21.setFont(new java.awt.Font("Helvetica Neue", 1, 12)); // NOI18N
        jLabel21.setText("Sales Person  :  ");
        jLabel21.setOpaque(true);

        jLabel22.setFont(new java.awt.Font("Helvetica Neue", 0, 12)); // NOI18N
        jLabel22.setText("Nadun");
        jLabel22.setOpaque(true);

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel21)
                .addGap(0, 0, 0)
                .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel13.add(jPanel31);

        jLabel23.setFont(new java.awt.Font("Helvetica Neue", 0, 12)); // NOI18N
        jLabel23.setText("2024-May-15   08:45:34 AM");
        jLabel23.setOpaque(true);

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        jPanel13.add(jPanel32);

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 256, Short.MAX_VALUE)
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 25, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel33);

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 256, Short.MAX_VALUE)
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 25, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel34);

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 256, Short.MAX_VALUE)
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 25, Short.MAX_VALUE)
        );

        jPanel13.add(jPanel35);

        jPanel4.setBorder(javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10));

        jPanel7.setBackground(new java.awt.Color(235, 235, 235));

        jLabel8.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Product Description");

        descriptionField.setEditable(false);
        descriptionField.setColumns(1);
        descriptionField.setLineWrap(true);
        descriptionField.setRows(5);
        descriptionField.setEnabled(false);
        jScrollPane2.setViewportView(descriptionField);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel8.setBackground(new java.awt.Color(235, 235, 235));

        jPanel10.setLayout(new java.awt.GridLayout(1, 0, 5, 0));

        jButton1.setBackground(new java.awt.Color(240, 120, 8));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("INVOICE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton1);

        jButton2.setForeground(new java.awt.Color(240, 120, 8));
        jButton2.setText("CUSTOMER");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton2);

        jScrollPane3.setBorder(null);
        jScrollPane3.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        jScrollPane3.setAutoscrolls(true);

        jPanel9.setLayout(new java.awt.CardLayout());
        jScrollPane3.setViewportView(jPanel9);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 930, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 674, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, 0)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void salePriceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salePriceActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_salePriceActionPerformed

    private void taxFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_taxFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_taxFieldActionPerformed

    private void paidFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_paidFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_paidFieldActionPerformed

    private void discountFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_discountFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_discountFieldActionPerformed

    private void invFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_invFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_invFieldActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed

    }//GEN-LAST:event_jButton3ActionPerformed

    private void barCodeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_barCodeKeyReleased
        String barcode = barCode.getText();
        if (MistakesHandler.isNumeric(barcode)) {
            if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                findProduct(barcode);
            }
        } else {
            barCode.setText("");
        }
    }//GEN-LAST:event_barCodeKeyReleased

    private void barCodeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barCodeMouseClicked
        if (evt.getClickCount() == 2) {
            focusBarcodeField();
        }
    }//GEN-LAST:event_barCodeMouseClicked

    private void qtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_qtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_qtyActionPerformed

    private void qtyKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_qtyKeyReleased
        String qty = this.qty.getText();
        if (qty.isEmpty()) {
            this.enteredQty = 1;
            this.qty.setText(String.valueOf(enteredQty));
            this.qty.selectAll();
        } else {
            if (qty.equals("0")) {
                this.enteredQty = 1;
                this.qty.setText(String.valueOf(this.enteredQty));
                this.qty.selectAll();
                singleTotalSetter();
            } else if (MistakesHandler.isNumeric(qty)) {
                this.enteredQty = Integer.parseInt(qty);
                singleTotalSetter();
                if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                    addItemToTable();
                    this.productCombo.grabFocus();
                    this.qty.setEditable(false);
                }
            } else {
                this.enteredQty = 1;
                this.qty.setText(String.valueOf(this.enteredQty));
                this.qty.selectAll();
            }
        }
    }//GEN-LAST:event_qtyKeyReleased

    private void qtyFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_qtyFocusGained
        qty.selectAll();
    }//GEN-LAST:event_qtyFocusGained

    private void qtyFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_qtyFocusLost
        enteredQty = 1;
        this.qty.setText(String.valueOf(enteredQty));
        singleTotalSetter();
    }//GEN-LAST:event_qtyFocusLost

    private void productComboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productComboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_productComboActionPerformed

    private void productComboMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_productComboMouseClicked
        if (evt.getClickCount() == 2) {
            focusProductField();
        }
    }//GEN-LAST:event_productComboMouseClicked

    private void productComboKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_productComboKeyReleased
        String barcode = productCombo.getText();
        if (MistakesHandler.isNumeric(barcode)) {
            if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                findProduct(barcode);
            }
        } else {
            barCode.setText("");
        }
    }//GEN-LAST:event_productComboKeyReleased

    private void discountFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_discountFieldKeyReleased
        discount = MistakesHandler.numericsMistakesHandler(discountField);
        calculate();
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            taxField.grabFocus();
        }
    }//GEN-LAST:event_discountFieldKeyReleased

    private void discountFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_discountFieldFocusGained
        discountField.selectAll();
        discount = MistakesHandler.numericsMistakesHandler(discountField);
    }//GEN-LAST:event_discountFieldFocusGained

    private void discountFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_discountFieldFocusLost
        MistakesHandler.numericsMistakesHandler(discountField);
    }//GEN-LAST:event_discountFieldFocusLost

    private void taxFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_taxFieldKeyReleased
        tax = MistakesHandler.numericsMistakesHandler(taxField);
        calculate();
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            pmField.grabFocus();
        }
    }//GEN-LAST:event_taxFieldKeyReleased

    private void taxFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_taxFieldFocusGained
        taxField.selectAll();
        MistakesHandler.numericsMistakesHandler(taxField);
    }//GEN-LAST:event_taxFieldFocusGained

    private void taxFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_taxFieldFocusLost
        MistakesHandler.numericsMistakesHandler(taxField);
    }//GEN-LAST:event_taxFieldFocusLost

    private void paidFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_paidFieldKeyReleased
        paid = MistakesHandler.numericsMistakesHandler(paidField);
        calculate();
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            jButton3.grabFocus();
            jButton3.setBackground(new Color(51, 180, 0));
            jButton3.setForeground(Color.white);
        }
    }//GEN-LAST:event_paidFieldKeyReleased

    private void paidFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_paidFieldFocusLost
        MistakesHandler.numericsMistakesHandler(paidField);
    }//GEN-LAST:event_paidFieldFocusLost

    private void pmFieldItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_pmFieldItemStateChanged
        calculate();
    }//GEN-LAST:event_pmFieldItemStateChanged

    private void paidFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_paidFieldFocusGained
        paidField.selectAll();
        MistakesHandler.numericsMistakesHandler(paidField);
    }//GEN-LAST:event_paidFieldFocusGained

    private void itemsTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemsTableMouseClicked
        if (evt.getClickCount() == 2 && itemsTable.getSelectedRow() != -1) {
            selectedRow = itemsTable.getSelectedRow();
            selectedRowValue = String.valueOf(itemsTable.getValueAt(selectedRow, 2));
            selectedRowPrice = String.valueOf(itemsTable.getValueAt(selectedRow, 3));
            jTextField1.setText(selectedRowValue);
            jTextField1.setVisible(true);
            clearBtn2.setVisible(true);
            jTextField1.grabFocus();
            jTextField1.selectAll();
        }
    }//GEN-LAST:event_itemsTableMouseClicked

    private void jTextField1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField1KeyReleased
        String v = jTextField1.getText();
        if (v.isEmpty()) {
            jTextField1.setText(selectedRowValue);
            jTextField1.selectAll();
        } else {
            if (v.equals("0")) {
                jTextField1.setText(selectedRowValue);
            } else if (MistakesHandler.isNumeric(v)) {
                if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                    itemsTable.setValueAt(jTextField1.getText(), selectedRow, 2);
                    itemsTable.setValueAt(Integer.parseInt(jTextField1.getText()) * Double.parseDouble(selectedRowPrice), selectedRow, 4);
                    jTextField1.setVisible(false);
                    clearBtn2.setVisible(false);
                    itemsTable.clearSelection();
                    discountField.grabFocus();
                    tableTotalCalcuate();
                }
            } else {
                jTextField1.setText(selectedRowValue);
            }
        }
    }//GEN-LAST:event_jTextField1KeyReleased

    private void jTextField1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextField1FocusLost
        if (jTextField1.getText().equals("")) {
            jTextField1.setText(selectedRowValue);
        } else {
            jTextField1.setText("");
        }
    }//GEN-LAST:event_jTextField1FocusLost

    private void clearBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtnActionPerformed
        fullClear();
    }//GEN-LAST:event_clearBtnActionPerformed

    private void clearBtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearBtn2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_clearBtn2ActionPerformed

    private void clearBtn2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearBtn2MouseClicked
        if (evt.getClickCount() == 2) {
            DefaultTableModel model = (DefaultTableModel) itemsTable.getModel();
            int index = Integer.parseInt(String.valueOf(itemsTable.getValueAt(selectedRow, 0)));
            int shouldUpdateRows = itemsTable.getRowCount() - index;

            model.removeRow(selectedRow);
            barcodeMap.remove(String.valueOf(index));

            for (int i = 0; i < shouldUpdateRows; i++) {
                barcodeMap.put(String.valueOf(index), barcodeMap.get(String.valueOf(index + 1)));
                itemsTable.setValueAt(index, index - 1, 0);
                index += 1;
            }
            clearBtn2.setVisible(false);
            jTextField1.setVisible(false);
            itemsTable.clearSelection();
            tableTotalCalcuate();

            if (itemsTable.getRowCount() == 0) {
                fullClear();
            }
        }
    }//GEN-LAST:event_clearBtn2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (invoicePreview != null) {
            invoicePreview.setVisible(false);
            invoiceAddCustomer.setVisible(true);
            jButton2.setBackground(new Color(240, 120, 8));
            jButton2.setForeground(Color.WHITE);
            jButton1.setBackground(Color.WHITE);
            jButton1.setForeground(new Color(240, 120, 8));
            SwingUtilities.updateComponentTreeUI(jPanel9);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (invoicePreview != null) {
            invoicePreview.setVisible(true);
            invoiceAddCustomer.setVisible(false);
            jButton1.setBackground(new Color(240, 120, 8));
            jButton1.setForeground(Color.WHITE);
            jButton2.setBackground(Color.WHITE);
            jButton2.setForeground(new Color(240, 120, 8));
            SwingUtilities.updateComponentTreeUI(jPanel9);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void itemsTableFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_itemsTableFocusLost

    }//GEN-LAST:event_itemsTableFocusLost

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton3KeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            completeInvoice();
        }
    }//GEN-LAST:event_jButton3KeyReleased

    private void jButton3FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jButton3FocusLost
        jButton3.setForeground(new Color(51, 180, 0));
        jButton3.setBackground(Color.white);
    }//GEN-LAST:event_jButton3FocusLost

    private void pmFieldKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_pmFieldKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            paidField.grabFocus();
        }
    }//GEN-LAST:event_pmFieldKeyReleased

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
        // TODO add your handling code here:
        completeInvoice();
    }//GEN-LAST:event_jButton3MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel availableQty;
    private javax.swing.JTextField balanceField;
    private javax.swing.JTextField barCode;
    private javax.swing.JButton clearBtn;
    private javax.swing.JButton clearBtn2;
    private javax.swing.JTextArea descriptionField;
    private javax.swing.JTextField discountField;
    private javax.swing.JTextField invField;
    private javax.swing.JTable itemsTable;
    public javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField netTotalField;
    private javax.swing.JTextField paidField;
    private javax.swing.JComboBox<String> pmField;
    private javax.swing.JTextField productCombo;
    private javax.swing.JLabel productName;
    private javax.swing.JTextField qty;
    private javax.swing.JTextField salePrice;
    private javax.swing.JTextField singleProductTotal;
    private javax.swing.JTextField taxField;
    private javax.swing.JTextField totalField;
    // End of variables declaration//GEN-END:variables
}
