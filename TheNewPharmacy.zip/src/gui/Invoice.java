package gui;

import java.awt.BorderLayout;

public class Invoice extends javax.swing.JDialog {
        
    public Invoice(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.setSize(1280, 700);
        this.setLocationRelativeTo(null);
        InvoicePanel invoicePanel = new InvoicePanel();
        this.add(invoicePanel,BorderLayout.CENTER);
        invoicePanel.setVisible(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
