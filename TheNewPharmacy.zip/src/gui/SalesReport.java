package gui;

import com.formdev.flatlaf.intellijthemes.FlatArcOrangeIJTheme;
import java.net.URL;
import java.nio.file.Paths;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import model.SQL;
import model.SalesBean;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.view.JasperViewer;

public class SalesReport extends javax.swing.JFrame {

    private DefaultTableModel model;

    private int TotalQty = 0;
    private double NetTotal = 0;

    private double MainTotal = 0;
    private double MainDis = 0;
    private double MainTax = 0;

    private void printReport() {

        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

//        String path = "src//reports//SalesReport.jasper";
        HashMap<String, Object> parameters = new HashMap();

        parameters.put("Title", "Monthly Sales Report");
        parameters.put("Person", String.valueOf(SignIn.userBean.getFname().toUpperCase()));
        parameters.put("Duration", "For");
        parameters.put("Duration1", String.valueOf(yearPicker.getSelectedItem()) + "/" + String.valueOf(monthPicker.getSelectedItem()));
        parameters.put("ReportedDate", format.format(date));
        parameters.put("TotalQty", String.valueOf(this.TotalQty));
        parameters.put("NetTotal", String.valueOf(this.NetTotal));

        parameters.put("MainTotal", String.valueOf(this.MainTotal));
        parameters.put("MainDis", String.valueOf(this.MainDis));
        parameters.put("MainTax", String.valueOf(this.MainTax));
        parameters.put("MainSubTotal", String.valueOf(((this.MainTotal - this.MainDis) + this.MainTax)));

        try {

            Vector v = new Vector();

            for (int i = 0; i < jTable1.getRowCount(); i++) {
                SalesBean bean = new SalesBean();
                bean.setCOLUMN_0(String.valueOf(jTable1.getValueAt(i, 0)));
                bean.setCOLUMN_1(String.valueOf(jTable1.getValueAt(i, 1)));
                bean.setCOLUMN_2(String.valueOf(jTable1.getValueAt(i, 2)));
                bean.setCOLUMN_3(String.valueOf(jTable1.getValueAt(i, 3)));
                bean.setCOLUMN_4(String.valueOf(jTable1.getValueAt(i, 4)));
                bean.setCOLUMN_5(String.valueOf(jTable1.getValueAt(i, 5)));

                v.add(bean);
            }
            
            URL reportPath = getClass().getResource("/reports/SalesReport.jasper");
            String path = Paths.get(reportPath.toURI()).toString();

            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(v);

            JasperPrint report = JasperFillManager.fillReport(path, parameters, dataSource);
            JasperViewer.viewReport(report, false);
        } catch (Exception e) {
            Logger logger = SignIn.log1;
            logger.warning(e.toString());
        }
    }

    private void saveReport() {
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

//        String path = "src//reports//SalesReport.jasper";
        HashMap<String, Object> parameters = new HashMap();

        parameters.put("Title", "Monthly Sales Report");
        parameters.put("Person", String.valueOf(SignIn.userBean.getFname().toUpperCase()));
        parameters.put("Duration", "For");
        parameters.put("Duration1", String.valueOf(yearPicker.getSelectedItem()) + "/" + String.valueOf(monthPicker.getSelectedItem()));
        parameters.put("ReportedDate", format.format(date));
        parameters.put("TotalQty", String.valueOf(this.TotalQty));
        parameters.put("NetTotal", String.valueOf(this.NetTotal));

        parameters.put("MainTotal", String.valueOf(this.MainTotal));
        parameters.put("MainDis", String.valueOf(this.MainDis));
        parameters.put("MainTax", String.valueOf(this.MainTax));
        parameters.put("MainSubTotal", String.valueOf(((this.MainTotal - this.MainDis) + this.MainTax)));

        try {

            Vector v = new Vector();

            for (int i = 0; i < jTable1.getRowCount(); i++) {
                SalesBean bean = new SalesBean();
                bean.setCOLUMN_0(String.valueOf(jTable1.getValueAt(i, 0)));
                bean.setCOLUMN_1(String.valueOf(jTable1.getValueAt(i, 1)));
                bean.setCOLUMN_2(String.valueOf(jTable1.getValueAt(i, 2)));
                bean.setCOLUMN_3(String.valueOf(jTable1.getValueAt(i, 3)));
                bean.setCOLUMN_4(String.valueOf(jTable1.getValueAt(i, 4)));
                bean.setCOLUMN_5(String.valueOf(jTable1.getValueAt(i, 5)));

                v.add(bean);
            }
            
            URL reportPath = getClass().getResource("/reports/SalesReport.jasper");
            String path = Paths.get(reportPath.toURI()).toString();

            JRBeanCollectionDataSource dataSource = new JRBeanCollectionDataSource(v);

            JasperPrint report = JasperFillManager.fillReport(path, parameters, dataSource);
            JasperExportManager.exportReportToPdfFile(report, "Report_" + System.currentTimeMillis() + ".pdf");
        } catch (Exception e) {
            Logger logger = SignIn.log1;
            logger.warning(e.toString());
        }
    }

    private void reset() {

        LocalDate currentDate = LocalDate.now();
        int currentYear = currentDate.getYear();
        yearPicker.setSelectedItem(String.valueOf(currentYear));
        monthPicker.setSelectedItem("05");
    }

    private void loadData() {
        
        this.TotalQty = 0;
        this.NetTotal = 0;
        this.MainTotal = 0;
        this.MainDis = 0;

        String year = String.valueOf(yearPicker.getSelectedItem());
        String month = String.valueOf(monthPicker.getSelectedItem());

        String query = "SELECT * FROM `invoice` "
                + "INNER JOIN `invoice_item` ON `invoice`.`invoice_id` = `invoice_item`.`invoice_id` "
                + "INNER JOIN `stock` ON `invoice_item`.`stock_barcode`=`stock`.`barcode` "
                + "INNER JOIN `product` ON `stock`.`product_id`=`product`.`id`  WHERE `invoice`.`date` LIKE '" + year + "-" + month + "%'";
        try {
            ResultSet rs = SQL.execute(query);

            int index = 1;
            this.model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);

            while (rs.next()) {

                Vector v = new Vector();

                double total = Double.parseDouble(rs.getString("stock.selling_price")) * Double.parseDouble(rs.getString("invoice_item.qty"));
                this.NetTotal += total;

                this.TotalQty += rs.getInt("invoice_item.qty");

                try {
                    ResultSet rs2 = SQL.execute("SELECT SUM(`total`) AS `total`, SUM(`discount`) AS `discount`, SUM(`tax`) AS `tax` FROM `invoice`");
                    if (rs2.next()) {
                        this.MainTotal = Double.parseDouble(String.valueOf(rs2.getString("total")));
                        this.MainDis = Double.parseDouble(String.valueOf(rs2.getString("discount")));
                        this.MainTax = Double.parseDouble(String.valueOf(rs2.getString("tax")));
                    }
                } catch (Exception e) {
                    Logger logger = SignIn.log1;
                    logger.warning(e.toString());
                }

                v.add(index);
                index++;

                v.add(rs.getString("stock.barcode"));
                v.add(rs.getString("product.name"));
                v.add(rs.getString("stock.selling_price"));
                v.add(rs.getString("invoice_item.qty"));
                v.add(total);

                model.addRow(v);

            }

        } catch (Exception e) {
            Logger logger = SignIn.log1;
            logger.warning(e.toString());
        }
    }

    public SalesReport() {
        initComponents();
        reset();
        loadData();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        monthPicker = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        yearPicker = new javax.swing.JComboBox<>();
        find = new javax.swing.JButton();
        find1 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 30)); // NOI18N
        jLabel1.setText("Sales Report");

        monthPicker.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }));

        jLabel2.setText("Month");

        jButton3.setBackground(new java.awt.Color(255, 0, 0));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel4.setText("Year");

        yearPicker.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2024", "2023" }));
        yearPicker.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                yearPickerActionPerformed(evt);
            }
        });

        find.setText("FIND");
        find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findActionPerformed(evt);
            }
        });

        find1.setText("RESET");
        find1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                find1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(yearPicker, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(monthPicker, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(find)
                .addGap(18, 18, 18)
                .addComponent(find1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 86, Short.MAX_VALUE)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(monthPicker, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(yearPicker, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(find, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(find1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        jPanel3.setLayout(new java.awt.BorderLayout());

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Index", "Barcode", "Product Name", "Unit Price", "Quantity", "Total"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(300);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
        }

        jPanel3.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jButton1.setText("SAVE REPORT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("PRINT REPORT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 352, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        saveReport();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void yearPickerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yearPickerActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_yearPickerActionPerformed

    private void findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findActionPerformed
        // TODO add your handling code here:
        loadData();
    }//GEN-LAST:event_findActionPerformed

    private void find1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_find1ActionPerformed
        // TODO add your handling code here:
        reset();
        loadData();
    }//GEN-LAST:event_find1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        printReport();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {

        FlatArcOrangeIJTheme.setup();

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SalesReport().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton find;
    private javax.swing.JButton find1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> monthPicker;
    private javax.swing.JComboBox<String> yearPicker;
    // End of variables declaration//GEN-END:variables
}
